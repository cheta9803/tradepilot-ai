class AngelAPIException(Exception):
    pass